import React from 'react'
import CartCSS from './Cart.module.css'

interface Props { }

interface State {
    isOpen: boolean
}

export default class Cart extends React.Component<Props, State>{
constructor(props: Props) {
        super(props)

        this.state = {
            isOpen: false
        }
    }
    render() {
return (
            <div className={CartCSS.cartContainer}>

                <button className={CartCSS.button}>2 pizza(s)</button>
                <div className={CartCSS.cartDropDown}>
                    <ul>
                        <li>Napoletana</li>
                        <li>Marinara</li>
                    </ul>
                </div>
            </div>
        )
    }

}


