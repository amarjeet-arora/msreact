



import React from 'react'

export default class Counter extends React.Component {

constructor(props) {
    super(props)

 
    this.state={
        count:0
    }
}

componentDidMount(){
    console.log('inside mount')
}

componentDidUpdate(){
    console.log('updating')
}
    handleAdd=()=>{
        this.setState((preState) =>{
            return {
                count: preState.count+1
            }
        })
     }

    handleminus(){
        alert('called minus')
    }
    handlereset(){
        alert('called reset')
    }

    render(){


        return (

            <div> <p>the current count is {this.state.count}</p>
                <button onClick={this.handleAdd}>++</button>
                <button onClick={this.handleminus}>--</button>
                <button onClick={this.handlereset}>reset</button>
            </div>
        )
    }


}