import React from 'react';

import './App.css';
import MainApp from './components/MainApp';

function App() {
  return (
    <div >
     
     
      <h3>welcome to react</h3>

      <MainApp/>

    </div>
  );
}

export default App;
