import React from 'react'

interface MyProps {
    name:string
}

const WelcomeDemo :React.FC<MyProps> =(props) =>{

   return <h1> Hello , {props.name}</h1> 
}

export default WelcomeDemo