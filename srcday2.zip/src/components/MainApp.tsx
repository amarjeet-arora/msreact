import React from 'react'
import pizzas from '../data/pizzas.json'
import Pizza  from './pizza'
import Cart from './Cart'
import AppCSS from './MainApp.module.css'



const MainApp =() =>{


return (
    <div className={AppCSS.container}>
        <div className={AppCSS.header}>
        <div className={AppCSS.siteTitle}>  Delicious Pizza </div>
        <Cart/>
        </div>
        <ul>
            {pizzas.map((pizza) =>{
                return <Pizza key={pizza.id} pizza={pizza} />
            })}
        </ul>
    </div>
)


}
export default MainApp