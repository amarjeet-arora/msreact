import React, { useState, useEffect } from 'react'


const HooksDemo =(props) =>{

   // const array=useState(10)
   const [count,setount] = useState(props.count)


useEffect(() =>{
    console.log('called once')
},[])

useEffect(() =>{
    console.log('called on update')
},[count])

    return(
        <div>
<p> the current count is {count}</p>

<button onClick={() => setount(count+1)}>inc</button>
<button onClick={() => setount(count-1)}>dec</button>
<button onClick={() => setount(props.count)}>reset</button>
</div>
    )
}

HooksDemo.defaultProps={
    count:0
}
export default HooksDemo