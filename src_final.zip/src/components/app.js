import React from "react";
import { Component } from "react";
import SearchBar from "./search_bar";
import WeatherList from "./weather_list";

 

export default class App extends Component {
  render() {
    return (
      <div>
        <center><h3>welcome to Weather App</h3></center>
       
       <SearchBar/>
       <WeatherList/>
      </div>
    );
  }
}
