import React from "react";
import { Component } from "react";
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import {fetchWeather} from '../actions/index'
 

 class SearchBar extends Component {
    constructor(props){
        super(props)

        this.state={
            term:''
        }
        this.onInputChange=this.onInputChange.bind(this)
        this.onFormSubmit=this.onFormSubmit.bind(this)
    }
    onInputChange(e){
        console.log(e.target.value)
        this.setState({term:e.target.value})
    }

    onFormSubmit(e) {
        alert('submited')
        e.preventDefault()
        this.props.fetchWeather(this.state.term);
        this.setState({term:''})

    }
    
  render() {
    return (
      <div>
       <h3>Enter City Name</h3>
       <form onSubmit={this.onFormSubmit}>
           <input type='text' placeholder='get a five day forcast of your city' name='city' className='form-control' value={this.state.term} onChange={this.onInputChange}/>
           <button className='btn btn-danger'> Search</button>
       </form>
      </div>
    );
  }
}

function mapDispatchToProps(dispatch){

  return bindActionCreators({fetchWeather},dispatch)

}

export default connect(null,mapDispatchToProps)(SearchBar)