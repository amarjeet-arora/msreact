import React from "react";
import { Component } from "react";

 

export default class WeatherList extends Component {
  render() {
    return (
      <div>
       <h3>Weather List</h3>
      </div>
    );
  }
}
